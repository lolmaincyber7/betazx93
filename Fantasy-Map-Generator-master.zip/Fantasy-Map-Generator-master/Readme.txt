Azgaar's Fantasy Map Generator
This is an open-source software available under MIT license
https://github.com/Azgaar/Fantasy-Map-Generator

To run the tool unzip ALL files and open index.html in browser